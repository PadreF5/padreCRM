// laravel-vue-auth/resources/js/app.js

require('./bootstrap');

import Vue from 'vue';

Vue.component('login-form', require('./components/auth/LoginForm.vue').default);
Vue.component('register-form', require('./components/auth/RegisterForm.vue').default);

const app = new Vue({
    el: '#app',
});
