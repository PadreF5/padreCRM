<!-- laravel-vue-auth/resources/js/components/auth/RegisterForm.vue -->

<template>
    <div>
        <h1>Register Form</h1>
        <!-- Your register form HTML goes here -->
    </div>
</template>

<script>
export default {};
</script>
