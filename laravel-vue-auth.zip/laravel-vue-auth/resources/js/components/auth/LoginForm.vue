<!-- laravel-vue-auth/resources/js/components/auth/LoginForm.vue -->

<template>
    <div>
        <h1>Login Form</h1>
        <!-- Your login form HTML goes here -->
    </div>
</template>

<script>
export default {};
</script>
