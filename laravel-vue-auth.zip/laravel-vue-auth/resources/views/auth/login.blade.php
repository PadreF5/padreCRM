<!-- laravel-vue-auth/resources/views/auth/login.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Laravel Vue.js Auth App - Login</title>
</head>
<body>

<div id="app">
    <login-form></login-form>
</div>

<script src="{{ mix('js/app.js') }}"></script>
</body>
</html>
