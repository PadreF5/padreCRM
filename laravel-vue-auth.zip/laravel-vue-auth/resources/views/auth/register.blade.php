<!-- laravel-vue-auth/resources/views/auth/register.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Laravel Vue.js Auth App - Register</title>
</head>
<body>

<div id="app">
    <register-form></register-form>
</div>

<script src="{{ mix('js/app.js') }}"></script>
</body>
</html>
